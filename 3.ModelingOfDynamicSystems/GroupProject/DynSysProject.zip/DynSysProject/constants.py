"""
All constants for oil resirvoir is listed bellow

Made by Torbjørn Madsen
"""
import numpy as np

"""__________________________________________________________________________"""
#Vertical pipe

def l_minus():
    """Length of vertical pipe bellow pump [m]"""
    return 100

def l_pluss():
    """Length of vertical pipe above pump [m]"""
    return 2000

def d():
    """Diameter of vertical pipw [m]"""
    return 0.1569

def r():
    """Radius of vertical pipw [m]"""
    return 0.1569/2

def epsilon():
    """Pipe roughness dimension [m]"""
    return 45.7e-6

"""__________________________________________________________________________"""
#Pressures

def p0():
    """Pressure at which ρ0 is known [Pa]"""
    return 1 * 100000

def pScale():
    """Scaling pressure [Pa]"""
    return 1 * 100000

"""__________________________________________________________________________"""
#Density

def rhoO():
    """Crude oil density[kg/m^3]"""
    return 900

def rhoW():
    """Water density [kg/m^3]"""
    return 1000

def rhoScale():
    """Desnity scaling [kg/m^3]"""
    return 10e3

"""__________________________________________________________________________"""
#KinematicViscosity

def nuO():
    """Kinematic viscosity of oil [m2/s]"""
    return 100e-6

def nuW():
     """Kinematic viscosity of water [m2/s]"""
     return 1e-6
 
 
"""__________________________________________________________________________"""
#Pump

def h_ps():
    """"Pump scaling head [m]"""
    return 1210.6

def V_s():
    """Pump scaling flow rate [kg/s]"""
    return 1

def f_p0():
    """nominal pump frequency [Hz]"""
    return 60

def a1():
    """ESP parameter"""
    return -37.57

def a2():
    """ESP parameter"""
    return 2.864e3

def a3():
    """ESP parameter"""
    return -8.668e4


"""__________________________________________________________________________"""
#Others

def bettaT():
    """Isothermal compressibility of fluid [Pa-1]"""
    return 1/(1.5e9)

def x_w():
    """Inlet water cut"""
    return 0.35

def C_m_dot():
    """Valve capacity in Eq. 24 [kg/h]"""
    return 25.9e-4

def C_v():
    """Productivity Index constant with, Eq. 16 [kg/s]"""
    return 7e-4

def g():
    """Gravitations accelration [m/s2]"""
    return 9.81;
