from matplotlib import pyplot




#%% Run main

if __name__=="__main__":
    ## Placeholders ##
    #   Constants
    Av          = 0
    rhov        = 0
    A           = 0
    rho         = 0
    g           = 9.8
    f_D         = 0
    D           = 0 #Is this a constant?
    l           = 0
    l_minus     = 0
    l_pluss     = 0
    C_Vdot      = 0
    P_scalePi   = 0
    VdotScale   = 0
    h_scaleP    = 0
    f_p         = 0
    f_p0        = 0
    a1          = 0
    a2          = 0
    a3          = 0
    
    P_f         = 0 # See appendix for Formation pressure development
    
    
    #   Equations, if 1 its found
    m_v         = 0 #From equation 41, how to define? Is is mass in entire pipe?
   
    
    
    Vdot_h      = 1
    h_p         = 1
    F_p         = 1
    v           = 1 #Need to use euler forward on thid
    Vdot_v      = 1 #Need to use Euler forward to obtain his
    
    
    # Equations
    #   Equations for Volumetric Acc
    P_h         = P_f-(Vdot_h*P_scalePi)/C_Vdot
    P_c         = (P_h-F_p)/A #From eq 37, should verify
    deltaP_p    = rho*g*h_p
    deltaP_f    = f_D*((rho*v^2)/(2*D))*l
    deltaP_g    = l_minus + l_pluss
    
    Vdot_h      = C_Vdot*((P_f-P_h)/P_scalePi)
    F_p         = A*(P_h-P_c)
    freq_hp     = f_p/f_p0 #Intermediate equation
    Vdot_hp     = Vdot/VdotScale #Intermdediater equation
    h_p         = (1/h_scaleP)*((freq_hp^2)+a1*(freq_hp*Vdot_hp)+a2*Vdot_hp^2+a3*Vdot_hp^3)

    dvdt        = (1/m_v)*F_tot #This is used in euler forward
    F_tot       = F_p+F_b-F_f-F_g   
    Vdot        = Vdot_v #Is this the same?
    F_b         = deltaP_p*A
    F_f         = deltaP_f*A
    F_g         = deltaP_g*A
    
    VolumetricAcc = (Av/rhov)*(P_h-P_c+deltaP_p-deltaP_f-deltaP_g)