from cgi import test
import constants as con
import numpy as np

class EF:
    
    def __init__(self, dt, start, end):
        
        self.dt = dt
        self.start = start
        self.end = end
    
        self.n = int((end-start)/dt)
        self.t = np.linspace(start, end, n+1)
        

    def V_v(self, init, Av, rho_v, l, p_h, p_ci, DeltaP_p, DeltaP_f, DeltaP_g):
        """Calculating volumetric flow rate  trought the pipe.
        init=initial condition, Av=Areal, rho_v=density, l=length, p_h=pressure innfluent,
        p_ci=pressure effluent, DeltaP_p=Pump pressure, DeltaP_f=Friction pressure,
        DeltaP_g=Gravitation pressure, dt=samling rate, n=sampling time"""
        
        V_v=np.zeros(self.n+1)
        V_v[0]= init
        
        for i in range(self.n):
            print(i)
            V_v[i+1] = V_v[i] + (Av/(rho_v[i]*l)*(p_h[i] - p_ci[i] + DeltaP_p[i] - DeltaP_f[i]))*self.t
        
        return V_v



if __name__ == "__main__":
    #Defining Parameters
    dt = 0.01
    
    start = 0
    end = 4
    
    test = test(dt, start, end)
     
    n = int((end-start)/dt)
    t = np.linspace(start, end, n+1)
    
    
    #Test av Euler forward
    rho_v = np.ones(n+1)
    A_v = np.pi*con.r()**2
    p_h =np.ones(n+1)
    p_ci = np.ones(n+1)
    DeltaP_p = np.ones(n+1)
    DeltaP_f = np.ones(n+1)
    DeltaP_g = np.ones(n+1)
    
    
    V = test.V_v(0.02315, A_v, rho_v, con.l_minus()+con.l_minus(), p_h, p_ci, DeltaP_p, DeltaP_f, DeltaP_g, dt, n)
    
    

    